RGB Cursor Set
==============

Author:
  - Phantom

This animated cursor set contains 13 cursors.

Installed by install.inf (1 file):
  - RGB Cursor Arrow.ani

Extras (12 files) — not installed automatically:
These are alternates and spare cursors included with the set. To use one,
copy it over the installed file it replaces, then re-apply the scheme in
Control Panel > Mouse > Pointers.
  - RGB Cursor Link_32.ani (32px)
  - RGB Cursor Text_32.ani (32px)
  - RGB Cursor Crosshair_32.ani (32px)
  - RGB NEResize Cursor 7_32.ani (32px)
  - RGB NWResize Cursor 8_32.ani (32px)
  - RBG Cursor NSResize 9_32.ani (32px)
  - RGB NSResize Cursor 10_32.ani (32px)
  - RGB Cursor Busy_32.ani (32px)
  - RGB Cursor Working_32.ani (32px)
  - RGB Cursor Unavailable_32.ani (32px)
  - RGB Cursor Alternate_32.ani (32px)
  - RBG Cursor Move 11_32.ani (32px)

Installation:
  1. Unzip this folder
  2. Right-click install.inf and choose 'Install'
     (Windows 11: choose 'Show more options' first)
  3. Open Mouse Properties, then its Pointers tab:
     - Search: click the search box on the taskbar (or Start),
       type  main.cpl  and press Enter
     - Or Run box: press the Windows key + R, type  main.cpl  and press Enter
     - Or Settings: Settings > Bluetooth & devices > Mouse >
       Additional mouse settings (older Windows: Control Panel > Mouse)
  4. Select 'RGB Cursor Set 248430' from the Scheme dropdown if it is not already selected
  5. Click OK

Downloaded from Cursors-4U.com
https://www.cursors-4u.com
